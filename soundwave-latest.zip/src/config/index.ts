export interface Config {
  STOREFRONT_ACCESS_TOKEN: string
  STOREFRONT_BASE_URL: string
}

const config: Config = {
  STOREFRONT_ACCESS_TOKEN: '2b31132c73ceaea88ff0dca4d9189876',
  STOREFRONT_BASE_URL: 'sensorium-arte.myshopify.com'
}

export default config
