import './styles/main.scss'
import { Customizer } from './/pages/customizer/customizer'
import React from 'react'

const App: React.FC = () => (
  <>
    <Customizer />
  </>
)
export default App
