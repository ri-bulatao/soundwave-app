// import type { ViteClientModule } from 'vite/client';

// Remove the above import statement if the type is not needed
